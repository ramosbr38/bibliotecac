<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <title>Biblioteca</title>
  <link rel="stylesheet" href="../css/estilo.css">
</head>
<body>
  <div class="container">
    <h1>Bem-vindo</h1>
    <a href="../visao/autores/listar.php">CRUD Autores</a>
    <a href="../visao/livros/listar.php">CRUD Livros</a>
  </div>
</body>
</html>
