<?php
class Autor {
    public $id, $nome, $nacionalidade, $data_nascimento;
}
