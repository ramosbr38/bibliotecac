<?php
class Livro {
    public $id, $titulo, $ano_publicacao, $editora, $status_leitura, $id_autor;
}
